package Test;

// 1번 문제
// -


// -

// 6번 문제
// : Object

// 7번 문제
// : ArrayCount

// 8번 문제
// :

// 9번 문제
// : 1

// 10번 문제
// : 2

// 11번 문제
// : Child

// 12번 문제
// : 2

// 13번 문제
// : 2

// 14번 문제
// :

// 15번 문제
// :

// 16번 문제
// : 3

// 17번 문제
// :

// 18번 문제
// :

// 19번
// : 빌더 패턴과 다운캐스팅, 추상클래스에 대해서 조금 더 알고 싶습니다.




// 20번
// : 수업 내용이 너무 알차고 세심하게 알려주셔서 배울 내용이 많아서 좋아요!
//   자바를 처음 접해 따라가기가 벅차긴 하지만 더 열심히 해서 따라가겠습니다! :)


import chapter12.model.Student;

import javax.net.ssl.SSLContextSpi;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
    // 2번 문제
        // 2-1)
        int num1 = 10;
        double num2 = 3.5;
        // 2-2)
        double result = num1 + num2;
        // 2-3)
        System.out.println(result);

    // 3번 문제
        // 3-1)
        int number = 2;






    // 4번 문제


    // 5번 문제
    // : class Test 바로 위에 클래스를 작성하고 main 메서드 내부에서 객체를 생성하세요.
        //5-1)



    }
}
